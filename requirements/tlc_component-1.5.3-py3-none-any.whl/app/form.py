from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Div, Layout
from .models import City

class DlgDgForm(forms.Form):

    batch_key = forms.CharField(max_length=200)

    def __init__(self, *args, **kwargs):
        super(DlgDgForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.form_action = '#'
        self.helper.form_id = "main_form"
        self.helper.form_class = 'form'
        self.helper.form_method = 'POST'
        self.helper.layout = Layout(
            Div(
                'batch_key'
            )
        )


class CityForm(forms.Form):

    class Meta:
        model = City
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super(CityForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.form_action = '#'
        self.helper.form_id = "main_form"
        self.helper.form_class = 'form'
        self.helper.form_method = 'POST'
        self.helper.layout = Layout(
            'name',
            'code'
        )