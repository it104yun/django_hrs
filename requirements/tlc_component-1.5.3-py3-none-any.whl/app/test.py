from unittest import TestCase

from django.contrib.staticfiles.testing import StaticLiveServerTestCase
from django.test import Client
from selenium.webdriver.chrome.webdriver import WebDriver


class ComponentTests(StaticLiveServerTestCase):

    @classmethod
    def setUpClass(cls) -> None:
        super().setUpClass()
        cls.selenium = WebDriver
        cls.selenium.implicitly_wait(time_to_wait=10)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.selenium.quit()
        super().tearDownClass()

    def test_datagrid(self) -> None:
        response = self.selenium.get('/dg_view')
        self.selenium.find_element_by_id('main_dg')