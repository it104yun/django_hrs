from django.http import JsonResponse
from django.shortcuts import render
from components.forms import SearchForm
from components.views import BaseLayoutView, SingleView, DoubleView
from .form import DlgDgForm, CityForm
from .models import City


def dg_view(request):
    fields = [
            {'name': 'code', 'verbose_name': '國別碼'},
            {'name': 'name', 'verbose_name': '名稱'},
    ]
    dg_config = dict(
        model=City,
        # display_fields=fields,
        display_fields=['code', 'name'],
        custom_fields=[
            {'name': 'continent', 'verbose_name': '洲別'}
        ],
        source_name='dg_source'
    )

    return render(request, 'dg_view.html', locals())


def dg_source(request):
    sort = request.GET.get('sort', 'code')
    order = request.GET.get('order', '')
    limit = int(request.GET.get('limit', 0))
    order = '-' if order=='desc' else ''
    field = request.GET.get('field', '')
    keyword = request.GET.get('keyword', '')

    cities = City.objects.all()
    if field and keyword:
        cities = cities.filter(**{field+'__contains': keyword})
    cities = cities.order_by(order+sort)
    if limit:
        cities = cities[0:limit]
    data = []
    for city in cities:
        data.append(dict(
            code=city.code,
            name=city.name,
            continent='--'
        ))
    return JsonResponse(data, safe=False)


def button_view(request):
    return render(request, 'button.html')


def edg_view(request):
    fields = [
        {'name': 'batch_no', 'verbose_name': '批次號碼'},
        {'name': 'job_no', 'verbose_name': '工單號碼'},
        {'name': 'material_no', 'verbose_name': '料號'},
        {'name': 'sop_no', 'verbose_name': 'SOPNO'}
    ]
    edg_config = dict(
        display_fields=fields,
        source_name='edg_source',
    )
    return render(request, 'edg_view.html', locals())


def edg_source(request):
    data = [
        {
            'batch_no': 'ABCDE123456',
            'job_no': '12345648798',
            'material_no': '1234QQQB',
            'sop_no': '11100215786'
         },
        {
            'batch_no': 'BD7894354s',
            'job_no': '4567896e5341',
            'material_no': 'f4e86e4f35sdf',
            'sop_no': '11101561351'
        }
    ]
    return JsonResponse(data, safe=False)


def dlg_fm_view(request):
    choices = ['code', 'name']
    dlg_fm_config = dict(
        form=SearchForm(model_class=City, display_fields=choices, ukey='dfm'),
    )

    return render(request, 'dlg_fm_view.html', locals())


def dlg_mono_dg_view(request):

    choices = ['code', 'name']
    dlg_mono_dg_config = dict(
        model=City,
        display_fields=choices,
        source_name='dg_source',
        form=SearchForm(model_class=City, display_fields=choices, ukey='mdl'),
    )

    return render(request, 'dlg_mono_dg_view.html', locals())


def dlg_view(request):
    return render(request, 'dlg_view.html')


def dlg_cpx_view(request):
    dlg_cpx_config = dict(
        cpx_fields=[
            {'name': 'code', 'verbose_name': '國別碼'},
            {'name': 'name', 'verbose_name': '名稱'},
        ],
        # cpx_model=City,
        cpx_ukey='uu',
        cpx_source_url='/api/cpx/city'
    )
    return render(request, 'dlg_cpx_view.html', locals())


def tree_view(request):
    tree_config = dict(
        source_url='/api/system_tree'
    )
    return render(request, 'tree_view.html', locals())


def tree_source(request):
    res = [{"id": "app", "text": "PDS ", "state": "open",
            "children": [{"id": "report", "text": "Report", "state": "open",
                          "children": [{"id": "sn210", "text": "SN210 ", "attributes": {"url": "/app/sn210"}}]}]}]
    return JsonResponse(res, safe=False)


def complex_view(request):
    dg_config = dict(
        model=City,
        display_fields=['code', 'name'],
        source_name='dg_source'
    )
    tree_config = dict(
        tree_url='api/system_tree'
    )
    dlg_cpx_config = dict(
        cpx_fields=['code', 'name'],
        cpx_model=City,
        cpx_ukey='cty'
    )

    return render(request, 'complex.html', locals())


class BaseView(BaseLayoutView):
    pass


class SingleObjectView(SingleView):
    form_class = CityForm
    form_param = {}
    main_model = City
    main_fields = ['name']
    main_sort = 'name'
    title = 'Single is NICE!'


class DoubleObjectView(DoubleView):
    form_class = CityForm
    form_param = {}
    main_model = City
    main_fields = ['name']
    main_sort = 'name'
    detail_model = City
    detail_fields = ['code']
    detail_sort = 'pk'
