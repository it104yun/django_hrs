from django.db import models

from components.utils import DictionaryMixin


class City(DictionaryMixin, models.Model):
    code = models.CharField(max_length=3, verbose_name="代碼")
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


