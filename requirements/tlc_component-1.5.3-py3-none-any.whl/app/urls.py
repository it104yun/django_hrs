"""app URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path, include
from .views import *

urlpatterns = [
    path('dg_view', dg_view),
    path('dg_source', dg_source, name="dg_source"),
    path('button_view', button_view),
    path('edg_view', edg_view),
    path('edg_source', edg_source, name="edg_source"),
    path('dlg_mono_dg_view', dlg_mono_dg_view),
    path('dlg_view', dlg_view),
    path('dlg_fm_view', dlg_fm_view),
    path('dlg_cpx_view', dlg_cpx_view),
    path('tree_view', tree_view),
    path('complex', complex_view),
    path('api/', include('components.urls')),
    path('api/system_tree', tree_source, name="system_tree"),
    path('base', BaseView.as_view()),
    # path('manipulate', ManipulateView.as_view()),
    path('single', SingleObjectView.as_view()),
    path('double', DoubleObjectView.as_view()),
]
