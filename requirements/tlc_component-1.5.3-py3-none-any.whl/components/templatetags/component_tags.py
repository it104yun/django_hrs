from django import template
from django.utils.safestring import mark_safe
from django.forms import Media
from components.component_registry import registry

register = template.Library()


@register.simple_tag(name="component_dependencies")
def component_dependencies_tag(*args, **kwargs):
    unique_component_classes = set(
        registry.get(name) for name in args)

    out = []
    media = Media()
    for component_class in unique_component_classes:
        component = component_class()
        media += component.media
    out.append(media.render())

    return mark_safe("\n".join(out))


@register.simple_tag(name="component")
def component_tag(name, *args, **kwargs):
    component_class = registry.get(name)
    component = component_class()
    return component.render(*args, **kwargs)

# credit for django_component by @EmilStenstrom
