from django.urls import path

from components.views import BaseCpxSearchHandle, ModelHandleView

urlpatterns = [
    path('cpx/<str:model>', BaseCpxSearchHandle.as_view(), name="complex_search"),
    path('data/<str:model>', ModelHandleView.as_view(), name="model_handler"),
    path('data/<str:model>/<str:pk>', ModelHandleView.as_view(), name="model_handler")
]