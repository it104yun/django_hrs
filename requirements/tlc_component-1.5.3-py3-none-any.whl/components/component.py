from django.forms.widgets import MediaDefiningClass
from django.template.loader import render_to_string
from six import with_metaclass


class Component(with_metaclass(MediaDefiningClass)):
    # 會預設一個 metaclass
    # class Media
    
    template = None
    """
    template 是元件本身的HTML
    context 是嵌入元件HTML的值
    
     <table id={{node_id}}>
     </table>
    
    整個table是 template
    node_id 是 context
    """

    def __init__(self, context=None):
        self.context = context

    def render(self, *args, **kwargs):
        # 產出元件HTML
        context = self.get_context(*args, **kwargs)
        return render_to_string(self.template, context)

    def get_context(self, config=None, *args, **kwargs):
        context = config if config else {}
        context.update({**kwargs})
        return context

# credit for django_component by @EmilStenstrom
