from django.conf import settings

from .component import Component
from .component_registry import register
from .forms import *

STATIC_URL = settings.STATIC_URL


class EasyForm(forms.ModelForm):
    class Media:
        css = {}
        js = (
            STATIC_URL + 'js/component/jquery.form.js',
            STATIC_URL + 'js/form.js'
        )


@register('dg')
class DataGrid(Component):

    template = 'component/datagrid.html'
    # 基本HTML。 在Component Class裡有定義。

    def get_context(self, config, *args, **kwargs):
        context = super().get_context(config, *args, **kwargs)
        key = config.get('key', '')
        sort = config.get('sort', '')
        self.model = config.get('model', '')
        self.custom_fields = config.get('custom_fields', [])
        self.display_fields = config.get('display_fields', '')
        self.config = config
        context.update({
            'sort': sort,
            'sort_order': 'desc',
            'key': key,
            'fields': self.get_field_list() if self.model else self.display_fields,
            'source': self.get_source_url(),
            'sortname': self.get_field_name() if self.model else self.display_fields,
        })
        return context
        # context 很重要! 在Component Class裡有定義。

    def get_source_url(self):
        source_url = self.config.get('source_url', '')
        if source_url:
            return source_url
        else:
            source_name = self.config.get('source_name', '')
        if not source_name:
            model_name = self.model.__name__
            _underscorer1 = re.compile(r'(.)([A-Z][a-z]+)')
            _underscorer2 = re.compile('([a-z0-9])([A-Z])')
            subbed = _underscorer1.sub(r'\1_\2', model_name)
            model_name = _underscorer2.sub(r'\1_\2', subbed).lower()
            return reverse_lazy('model_handler', kwargs={'model': model_name})
        return reverse_lazy(source_name)

    def get_field_list(self):
        if self.display_fields:
            fields = [field for field in self.model._meta.fields
                          if field.name in self.display_fields]
        else:
            fields = [field for field in self.model._meta.fields]
        fields.extend(self.custom_fields)
        return fields

    def get_field_name(self):
        if self.display_fields:
            return self.display_fields
        return [field.name for field in self.model._meta.fields]

    class Media:
        css = {'screen': (STATIC_URL + 'css/component/default/datagrid.css', )}
        js = (
                STATIC_URL + 'js/component/jquery.datagrid.js',
                STATIC_URL + 'js/component/datagrid.js',
                STATIC_URL + 'js/component/columns-ext.js',
        )


@register('edg')
class EditableDataGrid(DataGrid):
    template = 'component/edg.html'

    class Media:
        css = {'screen': (STATIC_URL + 'css/component/default/datagrid.css', )}
        js = (
                STATIC_URL + 'js/component/jquery.datagrid.js',
                STATIC_URL + 'js/component/edg.js',
        )


@register('btn')
class Button(Component):
    template = 'component/button.html'


@register('dlg')
class Dialog(Component):
    template = 'component/dlg.html'

    class Media:
        js = (
            STATIC_URL + 'js/component/dlg.js',
        )


@register('dlg_fm')
class DialogWithForm(Dialog):
    template = 'component/dlg_form.html'

    def get_context(self, config, *args, **kwargs):
        context = super().get_context(config, *args, **kwargs)
        if context.get('form', None) is None:
            raise Exception('缺少config，且必須指定form')
        return context


@register('dlg_cpx')
class ComplexDialog(Dialog):
    template = 'component/dlg_cpx.html'

    def get_context(self, config, *args, **kwargs):
        context = super().get_context(config, *args, **kwargs)
        cpx_model = config.get('cpx_model')
        cpx_fields = config.get('cpx_fields')
        cpx_ukey = config.get('cpx_ukey')
        cpx_source_url = config.get('cpx_source_url')
        context.update({
            'form': ComplexSearchForm(cpx_fields, cpx_model, cpx_source_url, cpx_ukey)
        })
        return context

    class Media:
        js = (
            STATIC_URL + 'js/component/dlg_cpx.js',
        )


# @register('dlg_dg')
# class DialogWithDatagrid(DataGrid, DialogWithForm):
#     template = 'component/dlg_dg_fm.html'

#     class Media:
#         js = (
#             STATIC_URL + 'js/component/dlg_dg.js',
#         )


@register('dlg_mono_dg')
class DialogMonoSearchDatagrid(DataGrid, DialogWithForm):
    template = 'component/dlg_mono_dg.html'

    class Media:
        js = (
            STATIC_URL + 'js/component/dlg_mono_dg.js',
        )



@register('tree')
class SystemTree(Component):
    template = 'component/tree.html'

    class Media:
        js = (
            STATIC_URL + 'js/component/tree.js',
        )