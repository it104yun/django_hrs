import re
from crispy_forms.helper import FormHelper
from crispy_forms.layout import (
    Button, Div, Field, Layout,
)
from django.utils.translation import gettext_lazy as _

from django import forms
from django.urls import reverse_lazy


class SearchForm(forms.Form):

    def __init__(self, display_fields, model_class=None, source='/', ukey='', *args, **kwargs):
        super(SearchForm, self).__init__(*args, **kwargs)
        self.model_class = model_class
        self.source = source
        if model_class:
            self.display_fields = [(f.name, f.verbose_name) for f in model_class._meta.fields
                                   if f.name in display_fields]
        else:
            self.display_fields = [(item['name'], item['verbose_name']) for item in display_fields]
        self.data = []
        self.fields['keyword'] = forms.CharField(label=_('Query Keyword'), required=True)
        self.fields['field'] = forms.ChoiceField(label=_('Query Field'), choices=self.display_fields, required=True)
        self.helper = FormHelper(self)
        self.helper.form_action = self.get_url()
        self.helper.form_id = ukey + "_monoSearchForm"
        self.helper.form_class = 'fm-search'
        self.helper.layout = Layout(
            Div(
                Field('field', id='field_' + ukey),
                css_class="p-2"
            ),
            Div(
                Field('keyword', id='keyword_' + ukey, size=60),
                css_class="p-2"
            ),
            Button('search_btn_' + ukey, _('Search'),
                   css_id='search_btn_' + ukey,
                   css_class="btn btn-sm btn-info btn-search")
        )

    def get_url(self):
        if self.model_class:
            return '/data/' + self.convert_model_name()
        return self.source

    def convert_model_name(self):
        r = re.compile(r'[A-Z][a-z0-9]+')
        model_name = self.model_class.__name__
        url_parameter = ''
        while len(model_name) > 0:
            # 把Model名稱轉為url參數
            # e.x. PdsMain -> pds_main
            match = r.match(model_name)
            if match:
                word = match.group()
                model_name = model_name[len(word)::]
                url_parameter = '{}{}_'.format(url_parameter, word.lower())
            else:
                break
        url_parameter = url_parameter[0:-1]
        # 最後一個_拿掉
        return url_parameter


class ComplexSearchForm(SearchForm):

    def __init__(self, display_fields, model_class=None, source=None, ukey='', *args, **kwargs):
        super(ComplexSearchForm, self).__init__(display_fields, model_class, source, ukey, *args, **kwargs)
        logic_config = {
            'choices': (
                ('any', _('Any')),
                ('all', _('All')),
            ),
            'widget': forms.RadioSelect,
        }
        relation_choices = [
            ('=', _('Equal')),
            ('include', _('Includes')),
            ('>', _('Greater than')),
            ('<', _('Less than')),
            ('!=', _('Not Equal')),
            ('exclude', _('Not Includes')),
        ]
        self.fields['logic'] = forms.TypedChoiceField(
            **logic_config, label=_('Filter Logic'))
        self.fields['relation'] = forms.ChoiceField(
            choices=relation_choices, label=_('Match Logic'))

        self.helper = FormHelper(self)
        self.helper.form_action = self.get_url()
        self.helper.form_id = "cpxSearchForm"
        self.helper.form_class = 'fm-cpx-search'
        self.helper.disable_csrf = True
        self.helper.layout = Layout(
            Div(
                Field('logic'),
                css_class="p-2 mb-1"
            ),
            Div(
                Div(
                    Field('field'),
                    css_class="col-2 p-0"
                ),
                Div(
                    Field('relation'),
                    css_class="col-2 p-0"
                ),
                Div(
                    Field('keyword', size=55),
                    css_class="col-6 p-0"
                ),
                Div(
                    Button(
                        'add_filter_btn',
                        _('Add'),
                        css_class="btn-sm position-absolute fixed-bottom btn-info add_filter_btn"),
                    css_class="position-relative col-1 "
                ),
                css_class="p-2 d-flex col bg-light"
            ),
        )

    def get_url(self):
        if self.source:
            return self.source
        elif self.model_class:
            url_parameter = self.convert_model_name()
            return reverse_lazy('complex_search', kwargs={'model': url_parameter})
        else:
            return '/'