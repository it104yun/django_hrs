import json
import logging
from datetime import datetime

from django.apps import apps
from django.core import serializers
from django.core.exceptions import FieldDoesNotExist, ObjectDoesNotExist
from django.db.models import Q
from django.forms import Media, modelform_factory
from django.forms.widgets import MediaDefiningClass
from django.http import JsonResponse
from django.urls import reverse
from django.utils import timezone
from django.views import View
from django.views.generic import TemplateView

from . import SearchForm
from .component import Component

logger = logging.getLogger('debug')
tracer = logging.getLogger('trace')


class ComponentMixinView(TemplateView, metaclass=MediaDefiningClass):
    """
    處理所有components的View插件。
    component_config是所有component的集合。
    """
    def __init__(self):
        self.component_config = {}

    def get_render_data(self):
        component_render_data = {}
        components = self.get_components()
        if not components:
            raise ValueError('Components cannot be empty.')
        media = Media()
        media += self.media
        for name, component in components.items():
            if not issubclass(component.__class__, Component):
                raise TypeError('%s should be a subclass of %s' % (name, Component))
            media += component.media
            component_render_html = component.render()
            component_render_data[name] = component_render_html
        component_render_data['dependencies'] = media.render()
        return component_render_data

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["components"] = self.get_render_data()
        return context

    def get_components(self):
        components = {
            name: self.create_component(component)
            for name, component in self.component_config.items()
        }
        return components

    @staticmethod
    def create_component(self, component):
        config = component['component_config']
        component_class = component['component_class']
        component_instance = component_class(config)
        return component_instance


class BaseCpxSearchHandle(View):

    def get(self, *args, **kwargs):
        self.model = kwargs.get('model', None)
        return super().get(*args, **kwargs)

    def model_name_trans(self):
        return ''.join([string.capitalize() for string in self.model.split('_')])

    def get_model_calss(self):
        model_name = self.model_name_trans()
        model_list = apps.get_models()
        try:
            model_class = [m for m in model_list if m.__name__ == model_name][0]
            return model_class
        except IndexError as e:
            return None

    def query(self, data, logic, filters):
        query = Q()
        if logic == 'all':
            for key, item in filters.items():
                if item['relation'] in ['exclude', '!=']:
                    query &= ~Q(**{'%s%s' % (item['field'], self.relation(item['relation'])): item['value']})
                else:
                    query &= Q(**{'%s%s' % (item['field'], self.relation(item['relation'])): item['value']})
        elif logic == 'any':
            for key, item in filters.items():
                if item['relation'] in ['exclude', '!=']:
                    query |= ~Q(**{'%s%s' % (item['field'], self.relation(item['relation'])): item['value']})
                else:
                    query |= Q(**{'%s%s' % (item['field'], self.relation(item['relation'])): item['value']})
        try:
            queryset = self.model_class.objects.filter(query)
        except FieldDoesNotExist as e:
            return None
        return queryset

    @staticmethod
    def serialize(result):
        return serializers.serialize('json', result)

    def post(self, *args, **kwargs):
        self.model = self.kwargs.get('model', None)
        self.model_class = self.get_model_calss()
        if not self.model_class:
            return JsonResponse({"status": False})
        else:
            post_param = self.request.POST
            data = json.loads(post_param['data'])
            logic = data.get('logic', 'all')
            filters = data.get('filter')

            result = self.query(data, logic, filters)
            return JsonResponse(self.serialize(result), safe=False)

    @staticmethod
    def relation(operator):
        mapping = {
            '>': '__gt',
            '<': '__lt',
            '=': '',
            'include': '__contains',
            '!=': '',
            'exclude': '__contains'
        }
        return mapping[operator]


class ModelHandleView(View):

    def parse_url(self, request):
        """
        擷取 model 參數，並找尋相對應的 Model class
        model參數會先依底線切開個單字後，做capitalize再合併。
        找不到對應 model class 回傳 404，反之回傳 Model Class 與 pk(如果有)

        ex.1
        model_parm = 'pds_main'
        model_name = PdsMain

        ex.2
        model_parm = 'PDS_main_testMain'
        model_name = PdsMainTestmain

        """
        model = self.kwargs['model']
        pk = self.kwargs.get('pk', None)
        model_name = ''.join([string.capitalize() for string in model.split('_')])
        model_list = apps.get_models()
        try:
            model_class = [m for m in model_list if m.__name__ == model_name][0]
        except IndexError as e:
            logger.debug(e)
            return JsonResponse({"success": False})
        else:
            return model_class, pk

    def get(self, request, *args, **kwargs):
        """
        GET 做兩件事: 讀取 / 刪除

        - 讀取
            <str:model>?sort=xx&order=OO&limit=100&factory=1000other_parameters
            以 other_parameters 篩選資料之後再處理sorting, ordering, limit 和 factory

        - 刪除
            <str:model>/<str:pk>
            取得 pk 刪除指定的資料。
        """
        model, pk = self.parse_url(request)
        get_param = request.GET.dict()
        tracer.info('get %s' % model._meta.model_name)
        if not pk:
            try:
                sort = get_param.pop('sort', None)
            except:
                pass
            try:
                order = get_param.pop('order', None)
            except:
                pass
            try:
                limit = get_param.pop('limit', None)
            except:
                pass
            try:
                latest = get_param.pop('latest', None)
            except:
                pass

            query = Q()
            for key, value in get_param.items():
                # _id 結尾通常是 foreignkey, 不支援 __contains
                key = key + '__contains' if not '_id' in key else key
                query &= Q(**{key: value})
            if latest:
                three_months = timezone.now() - datetime.timedelta(days=90)
                query &= Q(create_time__gt=three_months)
            data = model.objects.filter(query)
            # FIXME: 優化QQ 未來的你加油啊!

            if sort:
                order_syntext = '-' if order == 'desc' else ''
                data = data.order_by(order_syntext + sort)
            if limit:
                data = data[:int(limit)]
            dict_data = self._serialize(data, True)
            return JsonResponse(dict_data, safe=False)
        else:
            model.objects.filter(pk=pk).delete()
            return JsonResponse({"success": True})

    def post(self, request, *args, **kwargs):
        """
        POST 做兩件事: 新增 / 修改

        - 新增
            <str:model>
            新增資料。

        - 修改
            <str:model>/<str:pk>
            取得 pk 更新指定的資料。
        """
        model, pk = self.parse_url(request)
        post_param = request.POST.dict()
        if post_param.get('csrfmiddlewaretoken', None):
            post_param.pop('csrfmiddlewaretoken')
        # 拿掉 csrfmiddlewaretoken
        form = modelform_factory(model, exclude=[])
        current_tz = timezone.get_current_timezone()
        now = timezone.now().astimezone(current_tz).strftime('%Y-%m-%d %H:%M:%S')
        if pk:
            try:
                instance = model.objects.get(pk=pk)
            except ObjectDoesNotExist as e:
                f = form(request.POST)
                if f.is_valid():
                    f.save()
                    return JsonResponse({"success": True})
                else:
                    errors = f.errors
                    return JsonResponse({"success": False, "message": errors})
            else:
                q = instance.to_dict()
                q.update(**post_param)
                f = form(q, instance=instance)
                if f.is_valid():
                    f.save()
                    return JsonResponse({"success": True})
                else:
                    errors = f.errors
                    return JsonResponse({"success": False, "message": errors})
        else:
            f = form(request.POST)
            if f.is_valid():
                f.save()
                return JsonResponse({"success": True})
            else:
                errors = f.errors
                return JsonResponse({"success": False, "message": errors})

    def _serialize(self, obj, related=True):
        datas = [o.to_dict(related) for o in obj]
        return datas


class BaseLayoutView(TemplateView):
    title = None
    template_name = 'page/base.html'

    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'system_tree_config': dict(
                source_url=reverse('system_tree')
            ),
            "title": self.title
        })

        return context


class ManipulateBaseMixin:
    form_class = None
    form_param = {}

    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'new_btn_config': dict(
                text="建立新資料",
                node_id="new_btn",
                css_class="btn btn-sm btn-info"
            ),
            'create_btn_config': dict(
                text="新增",
                node_id="create_btn",
                css_class="btn btn-sm btn-info"
            ),
            'update_btn_config': dict(
                text="儲存更新",
                node_id="update_btn",
                css_class="btn btn-sm btn-info"
            ),
            'delete_btn_config': dict(
                text="刪除",
                node_id="delete_btn",
                css_class="btn btn-sm btn-disabled"
            ),
            'cancel_btn_config': dict(
                text="取消",
                node_id="cancel_btn",
                css_class="btn btn-sm btn-secondary"
            ),
            "form": self.form_class(**self.form_param),
        })

        return context


class SingleView(ManipulateBaseMixin, BaseLayoutView):
    main_model = None
    main_fields = []
    main_sort = None
    template_name = 'page/single_object_list.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        pk_name = self.main_model._meta.pk.name
        context.update({
            "main_dg_config": {
                'display_fields': self.main_fields,
                'key': pk_name,
                'sort_order': 'desc',
                'model': self.main_model,
                'sort': self.main_sort if self.main_sort else pk_name,
            },
            "mono_search_btn_config": dict(
                text="單一條件搜尋",
                node_id='main_mono_search_btn',
                css_class="btn btn-sm btn-outline-secondary"
            ),
            "complex_search_btn_config": dict(
                text="多條件搜尋",
                node_id="main_cpx_search_btn",
                css_class="btn btn-sm btn-outline-secondary"
            ),
            "mono_search_dlg_config": {
                "form": SearchForm(
                    model_class=self.main_model,
                    display_fields=self.main_fields,
                    ukey='main'
                )
            },
            "complex_search_dlg_config": {
                'cpx_model': self.main_model,
                'cpx_fields': self.main_fields,
                'cpx_ukey': 'cpx',
            },
            "column_order": self.main_fields,
        })
        return context


class DoubleView(SingleView):
    detail_model = None
    detail_fields = []
    detail_sort = 'pk'
    template_name = 'page/double_object_list.html'

    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        pk_name = self.detail_model._meta.pk.name
        context = super().get_context_data(**kwargs)
        context.update({
            "detail_dg_config": {
                'display_fields': self.detail_fields,
                'key': pk_name,
                'model': self.detail_model,
                'sort': pk_name if pk_name else self.detail_sort,
                'uneditable': []
            },
        })

        return context


