from django.db import models
from django.db.models.fields import DateTimeField, CharField, BooleanField
from django.db.models.fields.related import (
    ForeignKey,
    ManyToManyField,
    OneToOneField,
)
from django.utils import timezone

to_tz = timezone.get_default_timezone()


class DictionaryMixin:
    """Provide to_dict function to wrap model datas into a dictionary."""

    def to_dict(self, related=True):
        """
        Includes both field values and related pk if related is True.
        Otherwise it will only include field value.
        """
        data = dict()
        opt = self._meta.concrete_fields
        for field in opt:
            q = getattr(self, field.name)
            if isinstance(field, DateTimeField):
                parse_time = q.astimezone(to_tz).strftime("%Y-%m-%d %H:%M")\
                    if q else ''
                data[field.name] = parse_time
            elif (isinstance(field, ForeignKey) or
                  isinstance(field, ManyToManyField) or
                  isinstance(field, OneToOneField)):
                if related and q:
                    data[field.name] = q.__str__()
                    data['%s_id' % field.name] = q.pk
                else:
                    data[field.name] = q.__str__()
            elif isinstance(field, CharField) and field.choices:
                ch = field.choices
                try:
                    display = [c[1] for c in ch if c[0] == q][0]
                except IndexError as e:
                    display = ''

                if related:
                    data[field.name] = display
                    data['%s_id' % field.name] = q
                else:
                    data[field.name] = display
            elif isinstance(field, BooleanField):
                data[field.name] = str(q).capitalize()
            else:
                data[field.name] = q

        return data


class TimeMixin(models.Model):
    creator = models.CharField(max_length=10, blank=True, null=True, verbose_name="建立人員")
    create_time = models.DateTimeField(blank=True, null=True, verbose_name="建立時間")
    changer = models.CharField(max_length=10, blank=True, null=True, verbose_name="變更人員")
    change_time = models.DateTimeField(blank=True, null=True, verbose_name="變更時間")

    class Meta:
        abstract = True