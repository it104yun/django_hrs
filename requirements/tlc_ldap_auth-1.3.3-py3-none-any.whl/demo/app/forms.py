from django import forms
from django.contrib.auth.forms import AuthenticationForm as DjangoAuthenticationForm

FACTORY_CHOICES = [
    ('1000', '中良工業'),
    ('1001', '越南中良'),
]


class AuthenticationForm(DjangoAuthenticationForm):

    error_messages = {
        'invalid_login': "請輸入正確的帳號密碼，或是確認您有權限登入。"
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['factory'] = forms.ChoiceField(label='工廠', choices=FACTORY_CHOICES, required=True)