from django.http import HttpResponse


def main(request):
    result = "<p>%s</p><button onclick=\"location.href='/logout'\">Logout</button>" % request.session['user_cn']
    return HttpResponse(result)