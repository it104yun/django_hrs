from django.contrib.auth.base_user import AbstractBaseUser
from django.db import models


class CustomUser(AbstractBaseUser):
    username = models.CharField(primary_key=True, max_length=8, verbose_name="使用者名稱")
    name = models.CharField(blank=True, max_length=10, verbose_name="姓名")

    USERNAME_FIELD = 'username'
