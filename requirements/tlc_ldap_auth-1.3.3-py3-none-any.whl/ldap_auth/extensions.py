import logging
import ldap

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect, reverse
from django.utils import timezone

logger = logging.getLogger('debug')
tracer = logging.getLogger('trace')


class AuthBackend:

    def authenticate(self, request, username: str, password: str) -> object:
        exist = ldap_user_info(username, [])
        if exist:
            if ldap_valid(username, password, exist['dn']):
                tracer.info('ldap valid: %s' % username)
                try:
                    user_model = get_user_model()
                    user = user_model.objects.get(username=username)
                except Exception as e:
                    logger.error(e)
                    return None
                else:
                    tracer.info('pds valid: %s' % username)
                    # 帶出姓名
                    result = ldap_user_info(username, ['cn'])
                    if result:
                        name = result['cn'][0].decode('utf8')
                    else:
                        name = ''
                    if hasattr(user, 'name'):
                        if user.name != name:
                            # 如果有變動，就更新資料庫
                            user.name = name
                    user.last_login = timezone.now()
                    user.save()
                    return user
        return None

    def get_user(self, user_id):
        try:
            user_model = get_user_model()
            return user_model.objects.get(pk=user_id)
        except user_model.DoesNotExist as e:
            logger.error(e)
            return None


class AuthenticationMiddleware:

    def __init__(self, get_response):
        # One-time configuration and initialization.
        self.get_response = get_response

    def __call__(self, request):
        # Code to be executed for each request before
        # the view (and later middleware) are called.
        path = request.get_full_path()
        if 'login' in path:
            # Login 頁面排除
            tracer.info('login')
            return self.get_response(request)
        if not request.user.is_authenticated:
            # 未登入導至登入頁面
            tracer.info('redirect login')
            return redirect(reverse('login'))
        else:
            request = self.permission_handler(request)
        response = self.get_response(request)

        # Code to be executed for each request/response after
        # the view is called.
        return response

    def permission_handler(self, request):
        """
        除了login之外，各頁面的權限處理。
        """
        path = request.get_full_path()
        if '/admin/' in path:
            if request.user.username == 'admin':
                setattr(request.user, 'is_staff', True)
            return request
        elif '/app/' in path or '/system/' in path:
            factory_id = request.session['factory']['id']
            program_id = path.split('/')[2]
            result = request.user.has_permission(program_id, factory_id)
            if result:
                perm = result[0]
                tracer.info('access %s _ %s %s %s' % (path, perm.create, perm.update, perm.delete))
                request.session['perm'] = perm.to_dict()
                return request
            else:
                tracer.info('access %s _ no permission' % path)
                raise PermissionDenied()
        else:
            return request


def ldap_valid(user_id: str, user_pass: str, dn: str) -> bool:
    """
    LDAP 驗證帳密

    lasted update: 2020.04.28 修改 exception & return
    """
    l = ldap.initialize(settings.LDAP_HOST)
    base_dn = settings.LDAP_BASE_DN
    # user_dn = 'uid=' + user_id + ',ou=account,ou=staff,' + base_dn
    try:
        # print('ldap 驗証成功' if result[0]==97 and result[2]==1 else '')
        result = l.simple_bind_s(dn, user_pass)
        return True if result[0] == 97 and result[2] == 1 else False
    except ldap.INVALID_CREDENTIALS as e:
        #   print('無此使用者! \t ldap 驗証失敗' if ldap.INVALID_CREDENTIALS else '' )
        logger.error(e)
        return False


def ldap_user_info(user_id: str, keys=None) -> dict:
    """
    向 LDAP 取得名字

    lasted update: 2020.04.24 修改 exception & return
    """
    l = ldap.initialize(settings.LDAP_HOST)
    base_dn = settings.LDAP_BASE_DN

    # 先使用root login
    root_id = settings.LDAP_ROOT_ID
    root_pass = settings.LDAP_ROOT_PASS
    root_dn = 'cn=' + root_id + ',' + base_dn
    try:
        l.simple_bind_s(root_dn, root_pass)
    except ldap.LDAPError as e:
        logger.error(e)
        return {}

    # 檢查使用者名稱是否存在
    user_dn = 'uid=' + user_id + ',ou=staff,' + base_dn
    try:
        result = l.search_s(
            base_dn, ldap.SCOPE_SUBTREE,
            '(uid=%s)' % user_id
        )

    except ldap.NO_SUCH_OBJECT as e:
        logger.error(e)
        return {}
    else:
        dn = result[0][0]
        user_info = result[0][1]
        info = dict(dn=dn)

        if not keys:
            return info
        else:
            for key, value in user_info.items():
                if key in keys:
                    info[key] = value
        return info

