import logging
import importlib
from django.conf import settings
from django.contrib.auth.views import (
    LoginView as DjangoLoginView,
    LogoutView as DjangoLogoutView
)

from ldap_auth.extensions import ldap_user_info

logger = logging.getLogger('debug')
tracer = logging.getLogger('trace')


class LoginView(DjangoLoginView):

    def get_form_class(self):
        auth_form_set = getattr(settings, 'AUTH_FORM', None)
        if not auth_form_set:
            return self.authentication_form or self.form_class
        else:
            cut = auth_form_set.split('.')
            form_name = cut.pop()
            module = importlib.import_module('.'.join(cut))
            auth_form = getattr(module, form_name)
            return auth_form

    def form_valid(self, form):
        response = super().form_valid(form)
        user_info = ldap_user_info(form.get_user().username, ['cn'])
        self.request.session['user_cn'] = user_info['cn'][0].decode('utf-8')
        return response

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({
            'system_name': settings.SYSTEM_NAME
        })

        return context


class LogoutView(DjangoLogoutView):

    def get(self, request, *args, **kwargs):
        tracer.info('%s logout.' % self.request.user.username)
        return super().get(request, *args, **kwargs)


